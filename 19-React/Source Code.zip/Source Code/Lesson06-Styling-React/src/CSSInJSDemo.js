export default {
    CSSDemo_CSSInJS : {
        margin: '40px',
        border: '5px dashed blue'
    }
}