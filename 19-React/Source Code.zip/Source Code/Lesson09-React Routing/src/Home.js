import React from 'react';

const Home= () => {
    return(
        <div className="home">
            <h2>Welcome to the Home Of Our Application</h2>
            <p>Feel Free to Browse Around and Learn More About Us</p>
        </div>
    )
}

export default Home