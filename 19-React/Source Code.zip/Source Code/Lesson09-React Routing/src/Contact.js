import React from 'react';

const Contact= () => {
    return(
        <div className="contact">
            <h2>Contact Us</h2>
            <p> You Can Reach Us Via Email : <strong>hello@demo.com</strong></p>
        </div>
    )
}

export default Contact