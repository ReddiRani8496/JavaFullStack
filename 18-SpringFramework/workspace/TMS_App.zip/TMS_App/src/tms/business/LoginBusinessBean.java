package tms.business;

public interface LoginBusinessBean {
	
	public boolean loginUser(String userId);
	
}
