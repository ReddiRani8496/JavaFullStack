import java.util.Date;
class Test 
{
	
	public static void main(String[] args) 
	{
		Date dobj = new Date();	
		System.out.print(dobj);
	}
}
 