class IfTest 
{
	public static void main(String[] args) 
	{
		int x = 7;

		if(x = 0)
		{
			System.out.println("Hello World!");
		}
	}
}
