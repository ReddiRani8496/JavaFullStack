/* This Program is used to Illustrate the Usage of For Loop */

public class ForDemo
{
	public static void main(String args[])
	{
			int i;
		 //initializing the variable, checking for the condition, iterating through the loop
		// the loop continues till the condition is true 
	       for (i = 0; i <= 5; i++) 
			{
				 // displaying the values
	       			System.out.println(i+"\n");
			}
	}
}
