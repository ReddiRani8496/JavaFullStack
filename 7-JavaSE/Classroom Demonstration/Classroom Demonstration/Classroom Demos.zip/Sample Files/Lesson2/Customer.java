package oe;
/**
 *   Customer Class is meant maintaining Customer Details in Inventory App
 */
public class Customer 
{
	
	/**
	 *  Id Attribute Stores ID of the Customer
	 */
	public int id;

	/**
	 * Name Attribute Stores Name of the Customer
	 */
	public String name;

	public String address;


	/**
     *  Main Method is Entry Point for the Application
	 */
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}


class Order
{
}	


class OrderItem 
{
}