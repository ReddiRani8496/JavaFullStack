package training.oracle;

/**
 *  Product Class Maintains Details About the Products
 */
public class Product 
{

	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
