import java.util.Date;
class DateExample 
{
	public static void main(String[] args) 
	{
		Date dobj = new Date();
		System.out.println(dobj);
	}
}
