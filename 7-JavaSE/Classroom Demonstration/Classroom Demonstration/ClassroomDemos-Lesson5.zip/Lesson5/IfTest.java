class IfTest 
{
	public static void main(String[] args) 
	{
		int x = 8;

		if( x % 2 == 0){
			System.out.println("Its Even ");
			System.out.println("Yeah We Observed it ");
		}
		else{
			System.out.println("Its Odd  ");
		}
		
	}
}
