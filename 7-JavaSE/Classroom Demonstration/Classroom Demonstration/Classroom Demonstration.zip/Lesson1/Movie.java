/**
 *  Movie Class is Meant to Store Movie Information
 */
class Movie 
{

	/**
	 *  ID Attribute Stores ID of the Customer
	 */
	public int id;

	/**
	 *  Title Attribute Store Title of the Movie
	 */
	public String title;

	public String rating;


	/**
	 *  Main is the Entry Point of The Application
	 */
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
