class VariableDemo 
{
	static boolean ageLimit;

	public static void main(String[] args) 
	{
		//VariableDemo obj = new VariableDemo();
		System.out.println(ageLimit);
	}
}
