public class GuidedPractice
{
	public static void main(String args[])
	{
			/*
			int x = -3, y = 5;
			if (x >= 0)
			{
				if (y < x)
					System.out.println("y is less than x");
			}
			else
			{
				System.out.println("x is negative");
			}
			
			
			boolean x = false;
			if(x = true)
			{
				System.out.println("X is Zero ");
			}
		*/
		
		int x = 14, y = 24;
		
		// ; in the if indicates There is No Body Statements for this IF [ NULL BODY ]
		if ( (x % 2 == 0)  &&  (y % 2 == 0) );
		//		FALSE       &&      FALSE
		//				  FALSE 
		
		System.out.println("x and y are even");

	}
}

	