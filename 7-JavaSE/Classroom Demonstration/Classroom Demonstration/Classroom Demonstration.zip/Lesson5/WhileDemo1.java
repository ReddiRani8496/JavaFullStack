class WhileDemo1 
{
	public static void main(String[] args) 
	{
		int x = 10;

		while( x > 0)
		{
			System.out.println("X is " + x);
			x--;
		}
	}
}
