public class SwitchDemo1
{
	public static void main(String args[])
	{
		int choice = 38;
		
		switch (choice) 
		{
		  case 37:
			 System.out.println("Coffee?");
			 break;

		  case 45:
			 System.out.println("Tea?");
			 break;

		  default:
			 System.out.println("???");
			 break;
		  
		}
	}
}