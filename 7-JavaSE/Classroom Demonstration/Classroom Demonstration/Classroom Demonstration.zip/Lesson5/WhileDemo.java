/* This Program illustrates the Usage of While Loop */

public class WhileDemo
{
	public static void main(String args[])
	{
			int i = 0;
		 // checking for the value of i whether it is less than 10.
		 // till the condition satisfies the loop continues. 
		
			while(i < 10)
			{
				 // displaying the values
				System.out.println("Value of i is " + i);
				// incrementing the value
				i++;
			}
	}
}
