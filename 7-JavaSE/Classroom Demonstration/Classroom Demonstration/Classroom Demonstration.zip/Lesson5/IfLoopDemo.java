/* This Program illustrates the If Statement */

public class IfLoopDemo 
{
	public static void main(String[] args)
	{
		int loop1 = 100;
		int loop2 = 500;

		// checking for the less than condition
		if (loop1 < loop2)
		{
			// will display the statement if the condition is satisfied
			System.out.println("Welcome to World Of Java...");
		}
	}
}
