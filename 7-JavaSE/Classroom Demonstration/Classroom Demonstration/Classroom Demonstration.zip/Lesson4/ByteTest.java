class ByteTest 
{
	public static void main(String[] args) 
	{
		byte b1 = 127;
		
		long b2 = 127;

		long b3 = b1 + b2;

		System.out.println(b3);
	}
}
