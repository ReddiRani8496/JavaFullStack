import java.util.Date;

public class DateDemo 
{
	public static void main(String[] args) 
	{
		Date dobj = new Date();
		System.out.println(dobj);
	}
}
