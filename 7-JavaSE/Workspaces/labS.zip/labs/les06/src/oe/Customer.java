package oe;

public class Customer 
{
  public int id;
  public String name;
  public String address;
  public String phone;
}