package oe;

public class OrderEntry 
{
  public static void main(String[] args)
  {
    System.out.println("Order Entry Application");
  }
}