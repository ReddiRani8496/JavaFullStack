package oe;

public class Order
{
  int id;
  String orderDate;
  String shipMode;
  double orderTotal;
  String status;

  public int getId()
  {
    return id;
  }

  public String getOrderDate()
  {
    return orderDate;
  }

  public String getShipMode()
  {
    return shipMode;
  }

  public double getOrderTotal()
  {
    return orderTotal;
  }

  public String getstatus()
  {
    return status;
  }

  public void setId(int newId)
  {
  }

  public void setOrderDate(String newOrderDate)
  {
  }

  public void setShipMode(String newShipMode)
  {
  }

  public void setOrderTotal(double newOrderTotal)
  {
  }

  public void setStatus(String newStatus)
  {
  }
}