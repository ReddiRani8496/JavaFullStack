package oe;

public class DataMan {
    static Customer customer1 = 
        new Customer("Gary Williams", "Houston, TX", "713.555.8765");

    static Customer customer2 = 
        new Customer("Lynn Munsinger", "Orlando, FL", "407.695.2210");

    static Customer customer3 = 
        new Customer("Rachael O'leary", "Brisbane, QLD", "07.3031.1100");

    static Customer customer4 = 
        new Customer("Tony Obermeit", "Brisbane, QLD", "07.3031.9987");

    static Company customer5 = 
        new Company("Oracle", "Redwood Shores", "80", "Larry Ellison", 20);

    static Individual customer6 = 
        new Individual("Kate", "Baithentwaits", "676881", "54321");

}
