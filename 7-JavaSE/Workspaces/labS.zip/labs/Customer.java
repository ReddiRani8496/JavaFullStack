package oe;

public class Customer 
{
  int id;
  String name;
  String address;
  String phone;

  public int getId()
  {
    return id;
  }

  public String getName()
  {
    return name;
  }

  public String getAddress()
  {
    return address;
  }

  public String getPhone()
  {
    return phone;
  }

  public void setId(int newId)
  {
  }

  public void setName(String newName)
  {
  }

  public void setAddress(String newAddress)
  {
  }

  public void setPhone(String newPhone)
  {
  }
}