package oe;

import java.util.HashMap;

public class ProductMap extends HashMap {
}
