$(document).ready(function(){
  $('#photos').cycle({
    fx: 'shuffle'
  });
});
