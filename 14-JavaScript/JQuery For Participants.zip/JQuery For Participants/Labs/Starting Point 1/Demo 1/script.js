$(document).ready(function() {
	alert(' Welcome to StarTrackr App ! ');
});